'use strict'

const { goals } = require('mineflayer-pathfinder')
const Vec3 = require('vec3')
const log = require('../utils/log')
const { IptalEdildi, sinirli } = require('../utils/gorev')

/**
 * SKILL: Bir oyuncunun yanına git.
 *
 * İki tuzak vardı:
 *
 *  1) Oyuncu HAVADAYSA (creative'de uçarken) hedef nokta boşlukta kalıyordu.
 *     Oraya giden bir yol yok, pathfinder "Path was stopped before it could
 *     be completed" diyip vazgeçiyordu. Artık uçan oyuncunun ALTINDAKİ
 *     zemini hedefliyoruz.
 *
 *  2) Hedef bir kez hesaplanıyordu; oyuncu yürüyünce bot eski noktaya
 *     gidiyordu. Artık GoalFollow ile oyuncuyu canlı takip ediyor.
 */

/** Verilen noktanın altındaki ilk sağlam zemini bul (uçan oyuncu için) */
function altindakiZemin (bot, konum, maksDusus = 40) {
  const x = Math.floor(konum.x)
  const z = Math.floor(konum.z)

  for (let y = Math.floor(konum.y); y > Math.floor(konum.y) - maksDusus; y--) {
    const blok = bot.blockAt(new Vec3(x, y - 1, z))
    const ust = bot.blockAt(new Vec3(x, y, z))
    if (blok && blok.boundingBox === 'block' && ust && ust.name === 'air') {
      return new Vec3(x, y, z)
    }
  }
  return null
}

async function gel (bot, kontrol, oyuncuAdi, mesafe = 2) {
  const oyuncu = bot.players[oyuncuAdi]

  if (!oyuncu) {
    bot.chat(`${oyuncuAdi} diye birini görmüyorum.`)
    return { basarili: false, hata: 'oyuncu_yok' }
  }

  if (!oyuncu.entity) {
    bot.chat('Çok uzaktasın, seni göremiyorum — biraz yaklaş, tekrar "gel" yaz.')
    log.uyari(`${oyuncuAdi} görüş alanımda değil (entity yok).`)
    return { basarili: false, hata: 'oyuncu_gorunmuyor' }
  }

  const konum = oyuncu.entity.position
  const ayakAlti = bot.blockAt(konum.offset(0, -1, 0))
  const havada = !ayakAlti || ayakAlti.name === 'air'

  let hedefAciklama = 'yanına'
  let hedef

  if (havada) {
    // Uçuyor (creative) — altındaki zemine gidelim
    const zemin = altindakiZemin(bot, konum)
    if (!zemin) {
      bot.chat('Havadasın ve altında basacak zemin göremiyorum. Yere in, tekrar "gel" yaz.')
      return { basarili: false, hata: 'zemin_yok' }
    }
    hedef = new goals.GoalNear(zemin.x, zemin.y, zemin.z, mesafe)
    hedefAciklama = 'altındaki zemine'
    bot.chat('Havadasın — altındaki zemine geliyorum.')
  } else {
    // Yerdeyse canlı takip: yürürsen peşinden gelir
    hedef = new goals.GoalFollow(oyuncu.entity, mesafe)
  }

  log.bilgi(`${oyuncuAdi} ${hedefAciklama} gidiyorum...`)

  try {
    await sinirli(bot.pathfinder.goto(hedef), 45000, kontrol)
    bot.pathfinder.stop()
    log.basari('Geldim.')
    bot.chat('Geldim.')
    return { basarili: true }
  } catch (err) {
    bot.pathfinder.stop()
    if (err instanceof IptalEdildi) throw err

    log.hata(`Yol bulamadım: ${err.message}`)
    bot.chat(
      err.message === 'zaman_asimi'
        ? 'Çok uzun sürdü, vazgeçtim — daha yakın bir yerden dene.'
        : 'Yanına yol bulamadım. Arada uçurum, su ya da kapalı bir alan olabilir.'
    )
    return { basarili: false, hata: err.message }
  }
}

module.exports = { gel, altindakiZemin }
